// Script for adding interactivity
const galleryImages = document.querySelectorAll('.gallery-image');

galleryImages.forEach(image => {
    image.addEventListener('click', () => {
        // Remove active class from all images
        galleryImages.forEach(img => img.classList.remove('active'));

        // Add active class to the clicked image
        image.classList.add('active');

        // Create fullscreen view
        const fullScreenDiv = document.createElement('div');
        fullScreenDiv.classList.add('fullscreen');
        fullScreenDiv.innerHTML = `
            <img src="${image.src}" alt="Full Screen Image" class="fullscreen-image">
            <button class="close-btn">✖</button>
        `;
        document.body.appendChild(fullScreenDiv);

        const closeBtn = fullScreenDiv.querySelector('.close-btn');
        closeBtn.addEventListener('click', () => {
            document.body.removeChild(fullScreenDiv);
        });
    });
});

// Styling fullscreen view dynamically
const style = document.createElement('style');
document.head.appendChild(style);
